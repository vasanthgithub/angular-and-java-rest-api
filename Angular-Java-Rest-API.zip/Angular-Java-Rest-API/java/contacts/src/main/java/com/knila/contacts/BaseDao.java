/**
 * 
 */
package com.knila.contacts;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


/**
 * @author vasanthkumar
 *
 */
public class BaseDao {
	protected Connection connection = null;

	protected void getConnection() {
		// TODO Auto-generated method stub
		try {
			
			String database = "contacts";
			String dbpassword = "root";
			String dbuser = "postgres";
			String dbport = "5432";
			String dbhost = "localhost";

			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://" + dbhost + ":" + dbport + "/" + database,
					dbuser, dbpassword);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		} finally {
			
		}
		System.out.println("Opened database successfully");
	}

}
