/**
 * 
 */
package com.knila.contacts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.knila.contacts.BaseDao;


/**
 * @author vasanthkumar
 *
 */
public class Contact extends BaseDao{

	public boolean create(ContactModel contact) {
		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		boolean success = false;

		try {
			getConnection();

			String sql = "INSERT INTO contacts\n"
					+ "(first_name, last_name, email, phone_no, address, city, state, country, postalcode)\n"
					+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?);\n"
					+ "";

				statement = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
				
				statement.setString(1, contact.getFirstName());
				statement.setString(2, contact.getLastName());
				statement.setString(3, contact.getEmail());
				statement.setInt(4, contact.getPhoneNumber());
				statement.setString(5, contact.getAddress());
				statement.setString(6, contact.getCity());
				statement.setString(7, contact.getState());
				statement.setString(8, contact.getCountry());
				statement.setInt(9, contact.getPostalCode());
			


				int rowsInserted = statement.executeUpdate();
				if (rowsInserted > 0) {
					success = true;
				}else {
					throw new SQLException("Operation failed, no rows affected.");
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return success;
	}
	public ArrayList<ContactModel> get() {

		// TODO Auto-generated method stub

		ResultSet result;
		Statement statement = null;
		ArrayList<ContactModel> allContacts = new ArrayList<ContactModel>();
		try {
			getConnection();
			String sql = "SELECT id, first_name, last_name, email, phone_no, address, city, state, country, postalcode\n"
					+ "FROM contacts;\n"
					+ "";
			statement = connection.createStatement();
			result = statement.executeQuery(sql);

			while (result.next()) {
				System.out.println("Called............................."+result.getString(2));
				ContactModel contacts = new ContactModel();
				contacts.setId(result.getInt(1));
				contacts.setFirstName(result.getString(2));
				contacts.setLastName(result.getString(3));
				contacts.setEmail(result.getString(4));
				contacts.setPhoneNumber(result.getInt(5));
				contacts.setAddress(result.getString(6));
				contacts.setCity(result.getString(7));
				contacts.setState(result.getString(8));
				contacts.setCountry(result.getString(9));
				contacts.setPostalCode(result.getInt(10));
				
				allContacts.add(contacts);
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return allContacts;
	}
	
	public boolean update(ContactModel contact) {

		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		boolean success = false;
		try {
			getConnection();
			String sql = "UPDATE contacts SET first_name=?, last_name=?, email=?, phone_no=?, address=?, city=?, state=?, country=?, postalcode=? WHERE id = ?;";

			statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, contact.getFirstName());
			statement.setString(2, contact.getLastName());
			statement.setString(3, contact.getEmail());
			statement.setInt(4, contact.getPhoneNumber());
			statement.setString(5, contact.getAddress());
			statement.setString(6, contact.getCity());
			statement.setString(7, contact.getState());
			statement.setString(8, contact.getCountry());
			statement.setInt(9, contact.getPostalCode());
			statement.setInt(10, contact.getId());
			
			
			
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
				success = true;
			} else {
				throw new SQLException("Operation failed, no rows affected.");
			}

			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return success;
	}

	public boolean delete(int userId) {


		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		boolean success = false;
		try {
			getConnection();
			String sql = "DELETE FROM contacts WHERE id = ?;";

			statement = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

			statement.setInt(1, userId);

			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				success = true;
			}else {
				throw new SQLException("Operation failed, no rows affected.");
			}

			try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
	            if (generatedKeys.next()) {
	            	int lastInsertedId =generatedKeys.getInt(1);
	            }
	            else {
	                throw new SQLException("Operation failed, no ID obtained.");
	            }
	        }

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return success;
	}
}
