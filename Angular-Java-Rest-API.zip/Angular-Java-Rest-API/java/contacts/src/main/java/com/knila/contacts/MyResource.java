package com.knila.contacts;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;

import com.google.gson.Gson;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/contact")
public class MyResource {

	Contact contacts = new Contact();
//	
//	  @GET
//	    @Produces(MediaType.TEXT_PLAIN)
//	    public String getIt() {
//	        return "Got it!";
//	    }
	
	@Path("/create")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response create(ContactModel contact) {
		System.out.println("Called.............................");
		boolean success = contacts.create(contact);

		if (success) {
			return Response.status(200).entity("Success").build();
		} else {
			return Response.status(400).entity("Error").build();
		}
	}

	@Path("/get")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response get() {
		ArrayList<ContactModel> allContacts = contacts.get();
		String json = new Gson().toJson(allContacts);
		JSONArray arrayJson = new JSONArray(json);
		return Response.status(200).entity(arrayJson.toString()).build();
	}


	@Path("/update")
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response update(@Valid ContactModel model) {
		boolean success = contacts.update(model);
		if (success) {
			return Response.status(200).entity("Success").build();
		} else {
			return Response.status(400).entity("Error").build();
		}

	}

	@Path("/delete/{id}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response delete(@PathParam("id") int id) {
		boolean success = contacts.delete(id);

		if (success) {
			return Response.status(200).entity("Success").build();
		} else {
			return Response.status(400).entity("Error").build();
		}

	}
}
