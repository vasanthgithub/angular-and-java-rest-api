CREATE TABLE contacts
  (
     id            BIGSERIAL NOT NULL PRIMARY KEY,
     first_name    VARCHAR(50) NOT NULL,
     last_name     VARCHAR(50) NOT NULL,
     email         VARCHAR(50)  NOT NULL,
     phone_no        VARCHAR(15)  NULL,
     address         TEXT,
     city    VARCHAR(50) NOT NULL,
     state    VARCHAR(50) NOT NULL,
     country    VARCHAR(50) NOT NULL,
     postalcode    VARCHAR(50) NOT NULL
  );
 