import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CreateContactService } from './create-contact.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-create-contact',
  templateUrl: './create-contact.component.html',
  styleUrls: ['./create-contact.component.scss'],
})
export class CreateContactComponent implements OnInit {
  contactForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    email: new FormControl(''),
    phoneNumber: new FormControl(''),
    address: new FormControl(''),
    city: new FormControl(''),
    state: new FormControl(''),
    country: new FormControl(''),
    postalCode: new FormControl(''),
  });
  constructor(private _createContactService: CreateContactService,private router: Router) {}

  ngOnInit(): void {}
  createContact() {
    console.log(JSON.stringify(this.contactForm.value));
    this._createContactService.saveContact(this.contactForm.value).subscribe(
      (data: any) => {
        console.log(JSON.stringify(data));
        // this.products=data;
        this.router.navigateByUrl('/content');
      },
      (err) => {
        console.error(err);
        if(err.status === 200){
          this.router.navigateByUrl('/content');
        }
      },
      () => console.log('Products are loaded!')
    );
    
  }
}
