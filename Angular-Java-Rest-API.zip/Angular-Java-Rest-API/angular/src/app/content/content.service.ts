import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const headers = new HttpHeaders().set('content-type', 'application/json');
const options = { headers: headers };

@Injectable({
  providedIn: 'root',
})
export class ContentService {
  constructor(private _httpClient: HttpClient) {}

  getContacts() {
    var apiUrl = 'http://localhost:8080/contacts/api/contact/get';
    return this._httpClient.get(apiUrl, options);
  }
  deleteContacts(id:any){
    var apiUrl = 'http://localhost:8080/contacts/api/contact/delete/'+id;
    return this._httpClient.delete(apiUrl, options);
  }
}
