
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const headers = new HttpHeaders().set('content-type', 'application/json');
const options = { headers: headers };

@Injectable({
  providedIn: 'root',
})
export class UpdateContactService {
  constructor(private _httpClient: HttpClient) {}

  saveContact(params:any) {
    var apiUrl = "http://localhost:8080/contacts/api/contact/update";
    return this._httpClient.put(apiUrl, params, options);
  }
 
}