import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateContactService } from './update-contact.service';
import { ActivatedRoute, Params} from '@angular/router';
@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.scss']
})
export class UpdateContactComponent implements OnInit {
  contactForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    email: new FormControl(''),
    phoneNumber: new FormControl(''),
    address: new FormControl(''),
    city: new FormControl(''),
    state: new FormControl(''),
    country: new FormControl(''),
    postalCode: new FormControl(''),
  });
  datauserId: any;
  data: any;
  constructor(private activatedRoute: ActivatedRoute,private _updateContactService: UpdateContactService,private router: Router) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
       this.data = JSON.parse(params['data']);
      console.log(this.data.id);
      this.contactForm.controls.firstName.setValue(this.data.firstName);
      this.contactForm.controls.lastName.setValue(this.data.lastName);
      this.contactForm.controls.email.setValue(this.data.email);
      this.contactForm.controls.phoneNumber.setValue(this.data.phoneNumber);
      this.contactForm.controls.address.setValue(this.data.address);
      this.contactForm.controls.city.setValue(this.data.city);
      this.contactForm.controls.state.setValue(this.data.state);
      this.contactForm.controls.country.setValue(this.data.country);
      this.contactForm.controls.postalCode.setValue(this.data.postalCode);
    });
  }
  createContact() {
    console.log(JSON.stringify(this.contactForm.value));
    this.contactForm.value.id = this.data.id;
    this._updateContactService.saveContact(this.contactForm.value).subscribe(
      (data: any) => {
        console.log(JSON.stringify(data));
        // this.products=data;
        this.router.navigateByUrl('/content');
      },
      (err) => {
        console.error(err);
        if(err.status === 200){
          this.router.navigateByUrl('/content');
        }
      },
      () => console.log('Products are loaded!')
    );
    
  }
}
